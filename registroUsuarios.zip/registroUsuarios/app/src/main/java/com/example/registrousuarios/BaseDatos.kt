package com.example.registrousuarios

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Environment
import android.view.View
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.database.*
import com.google.firebase.database.R
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.io.File
import java.io.Serializable
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.CountDownLatch

class BaseDatos{

    val db_ref= FirebaseDatabase.getInstance().getReference()
    val sto_ref= FirebaseStorage.getInstance().getReference()

    //==============IMAGEN===================
    suspend fun insertoImagen(id:String,foto: Uri):String{

        lateinit var urlImagenFirebase: Uri

        urlImagenFirebase= sto_ref.child("Cuentas").child("imagenesUsuarios").child(id)
            .putFile(foto).await().storage.downloadUrl.await()

        return urlImagenFirebase.toString()

    }
    //======================================

    fun insertoUsuarioId(id:String,nombre:String,contrasena:String,admin:Boolean,imagenAvatar:String,fechaRegistro:String,
                         disponible:Boolean,mascota:Boolean,estadoNoti:Int,nomAnterior:String){

        val crearCuenta=Cuenta(id,nombre,contrasena,admin,imagenAvatar,fechaRegistro,disponible,mascota,estadoNoti,nomAnterior)

        db_ref.child("Cuentas").child("Usuarios").child(id).setValue(crearCuenta)

    }

    fun comprueboSiExiste(nombre:String):Boolean{
        var existe=false
        val semaforo= CountDownLatch(1)

        db_ref.child("Cuentas").child("Usuarios").orderByChild("nombre").equalTo(nombre)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    if(snapshot.hasChildren()){
                        existe=true
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        semaforo.await()
        return existe
    }

    fun comprueboCoincide(com_nombre: String,com_contrasena:String):Boolean{
        var coincide=false
        val semaforo= CountDownLatch(1)

        db_ref.child("Cuentas").child("Usuarios").orderByChild("nombre").equalTo(com_nombre)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    if(snapshot.hasChildren()){
                        val usuario=snapshot.children.iterator().next().getValue(Cuenta::class.java)
                        if(usuario?.nombre.toString()==com_nombre.trim() && usuario?.contrasena.toString()==com_contrasena){
                            coincide=true
                        }
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        semaforo.await()
        return coincide
    }

    fun sacoUsuarioDeLaBase(nombrePasado:String):Cuenta?{

        var coincide=false
        var usuario:Cuenta?=null
        val semaforo= CountDownLatch(1)



        db_ref.child("Cuentas").child("Usuarios").orderByChild("nombre").equalTo(nombrePasado)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    if(snapshot.hasChildren()){
                        usuario= snapshot.children.iterator().next().getValue(Cuenta::class.java)!!
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        semaforo.await()

        return usuario

    }

    fun sacoUsuConIDDeLaBase(idPasado:String):Cuenta{

        var coincide=false
        var usuario=Cuenta()
        val semaforo= CountDownLatch(1)

        db_ref.child("Cuentas").child("Usuarios").orderByChild("id").equalTo(idPasado)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    usuario= snapshot.children.iterator().next().getValue(Cuenta::class.java)!!
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        semaforo.await()

        return usuario

    }

    fun crearFicheroImagen(c:Context): File {
        val cal: Calendar?= Calendar.getInstance()
        val timeStamp:String?= SimpleDateFormat("yyyyMMdd_HHmmss").format(cal!!.time)
        val nombreFichero:String?="JPGE_"+timeStamp+"_"
        val carpetaDir: File?=c.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        val ficheroImagen: File?= File.createTempFile(nombreFichero!!,".jpg",carpetaDir)

        return ficheroImagen!!
    }

}



