package com.example.registrousuarios

class Estados {
    companion object{
        const val NOTIFICADO=0
        const val CREADO=1
        const val NOMBRE_CAMBIADO=2
        const val DADOBAJA=3
        const val DISPONIBLE=4
        const val NONOTIFICAR=-1

    }
}