package com.example.registrousuarios

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.io.Serializable
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicInteger

class Login : AppCompatActivity() {

    lateinit var nombre:TextInputEditText
    lateinit var contrasena:TextInputEditText

    lateinit var login:Button
    lateinit var registrarse:TextView

    lateinit var db_ref: DatabaseReference
    lateinit var sto_ref: StorageReference
    lateinit var SP: SharedPreferences

    lateinit var FunDB:BaseDatos
    lateinit var builder:NotificationCompat.Builder

    companion object{
        val APP_ID = "com.example.registrousuarios"
        val CHANNEL_ID = "${APP_ID}_c1"
        var id = AtomicInteger(0)

        fun create_notification_id():Int{
            return id.incrementAndGet()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        createNotificationChannel()
    }

    override fun onStart() {
        super.onStart()

        FunDB=BaseDatos()

        nombre=findViewById(R.id.login_nombre)
        contrasena=findViewById(R.id.login_contrasena)
        login=findViewById(R.id.login_btn_login)
        registrarse=findViewById(R.id.login_tv_registrarse)

        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()

        nombre.setText("")
        contrasena.setText("")

        val app_id=resources.getString(R.string.app_id)
        val sp_name="${app_id}_SP_APP"
        SP=getSharedPreferences(sp_name,0)

        SP.edit().putString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef)).commit()
        SP.edit().putBoolean(getString(R.string.admin),false).commit()

        registrarse.setOnClickListener {
            val intent=Intent(applicationContext,Registro::class.java)
            startActivity(intent)
        }

        login.setOnClickListener {
            login.isEnabled=false
            if(nombre.text.toString()=="" || contrasena.text.toString()==""){
                Toast.makeText(applicationContext, "Todo vacio", Toast.LENGTH_SHORT).show()
                login.isEnabled=true
            }else{
                GlobalScope.launch(Dispatchers.IO){

                    if(FunDB.comprueboCoincide(nombre.text.toString().trim(),contrasena.text.toString().trim())){
                        SP.edit().putString(getString(R.string.id_usuario),
                            FunDB.sacoUsuarioDeLaBase(nombre.text.toString())?.id.toString()).commit()
                        SP.edit().putBoolean(getString(R.string.admin),
                            FunDB.sacoUsuarioDeLaBase(nombre.text.toString())?.admin!!).commit()
                        val intent=Intent(applicationContext,PaginaPrincipal::class.java)
                        startActivity(intent)
                        activoCorrutina(login,true)

                    }else{
                        tostadaCorrutina("Error en contraseña o usuario")
                        activoCorrutina(login,true)
                    }
                }
            }

        }

        //NOTIFICACIONES
        db_ref.child("Cuentas").child("Usuarios").addChildEventListener(object :ChildEventListener{
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val usuariosUsu=snapshot.getValue(Cuenta::class.java)
                var spID=SP.getString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef))

                if(usuariosUsu!!.notiEstados==Estados.CREADO){
                    if(spID!="vacio"){
                        crearNotificacion("Cuenta creada!","${usuariosUsu.nombre}",R.drawable.ic_baseline_person_add_24)
                        db_ref.child("Cuentas").child("Usuarios").child(usuariosUsu.id!!).child("notiEstados").setValue(Estados.NOTIFICADO)
                    }

                }

            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                val usuariosUsu=snapshot.getValue(Cuenta::class.java)
                if (usuariosUsu!!.nombre !=usuariosUsu!!.nombreAnterior){

                    if(usuariosUsu!!.notiEstados==Estados.NOMBRE_CAMBIADO && SP.getString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef))!=usuariosUsu.id!!){
                        crearNotificacion("Cuenta modificada!","Nombre anterior: ${usuariosUsu.nombreAnterior}, Actual: ${usuariosUsu.nombre}",R.drawable.ic_baseline_person_add_24)
                        db_ref.child("Cuentas").child("Usuarios").child(usuariosUsu.id!!).child("notiEstados").setValue(Estados.NOTIFICADO)
                    }

                }

                if(usuariosUsu!!.notiEstados==Estados.DISPONIBLE && SP.getString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef))!=usuariosUsu.id!!){
                    crearNotificacion("${usuariosUsu.nombreAnterior}","Vuelve a estar Online!",R.drawable.ic_baseline_person_add_24)
                    db_ref.child("Cuentas").child("Usuarios").child(usuariosUsu.id!!).child("notiEstados").setValue(Estados.NOTIFICADO)
                }

            }

            override fun onChildRemoved(snapshot: DataSnapshot) {
                val usuariosUsu=snapshot.getValue(Cuenta::class.java)
                if(usuariosUsu!!.notiEstados==Estados.DADOBAJA && SP.getString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef))!="vacio"){
                    crearNotificacion("Cuenta dada de baja!","${usuariosUsu.nombre}",R.drawable.ic_baseline_person_add_24)
                    db_ref.child("Cuentas").child("Usuarios").child(usuariosUsu.id!!).child("notiEstados").setValue(Estados.NOTIFICADO)
                }
            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {

            }

            override fun onCancelled(error: DatabaseError) {

            }
        })



    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
        val intent:Intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        intent.flags=Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
    }

    //----------ACTIVO/DESACTIVO BOTON CORRUTINA-------
    private suspend fun activoCorrutina(v: View, boolean: Boolean){
        runOnUiThread {
            v.isEnabled=boolean
        }
    }
    //------------------------------------------------



    //-------HACER UN TOAST EN UNA CORRUTINA------------
    private suspend fun tostadaCorrutina(texto:String){
        runOnUiThread{
            Toast.makeText(applicationContext,texto,Toast.LENGTH_SHORT).show()

        }
    }
    //---------------------------------------------------

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = getString(R.string.notName)
            val descriptionText = getString(R.string.notDesc)
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun crearNotificacion(titulo:String,descripcion:String,icono:Int){
        val id = create_notification_id()

        val pendingIntent = PendingIntent.getActivity(this, 0, intent, 0)

        builder = NotificationCompat.Builder(this, Login.CHANNEL_ID)
            .setSmallIcon(icono)
            .setContentTitle(titulo)
            .setContentText(descripcion)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            //.setLargeIcon(imagen)
            //PARA BIG TEXT STYLE:
            //.setStyle(NotificationCompat.BigTextStyle().bigText(getString(R.string.texto_largo)))
            //PARA BIG PICTURE STYLE:
            //.setStyle(NotificationCompat.BigPictureStyle().bigPicture(imagen))
            .setAutoCancel(true)

        with(NotificationManagerCompat.from(this)) {
            notify(id, builder.build())
        }

    }
}