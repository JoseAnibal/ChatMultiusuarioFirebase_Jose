package com.example.registrousuarios

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.registrousuarios.databinding.ActivityVerUsuariosBinding
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class VerUsuarios : AppCompatActivity() {
    lateinit var bind:ActivityVerUsuariosBinding
    lateinit var lista_usuarios:MutableList<Cuenta>

    lateinit var db_ref: DatabaseReference
    lateinit var sto_ref: StorageReference
    lateinit var SP:SharedPreferences

    lateinit var FunDB:BaseDatos

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ver_usuarios)

        bind= ActivityVerUsuariosBinding.inflate(layoutInflater)
        setContentView(bind.root)
    }

    override fun onStart() {
        super.onStart()

        FunDB= BaseDatos()

        lista_usuarios= mutableListOf()
        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()

        val app_id=resources.getString(R.string.app_id)
        val sp_name="${app_id}_SP_APP"
        SP=getSharedPreferences(sp_name,0)

        if(guardaespaldas()){
            val usuarioActualId=SP.getString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef))?:"vacio"

            db_ref.child("Cuentas")
                .child("Usuarios")
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        lista_usuarios.clear()
                        snapshot.children.forEach{ hijo: DataSnapshot?->

                            val pojo_poke=hijo?.getValue(Cuenta::class.java)

                            lista_usuarios.add(pojo_poke!!)
                        }

                        bind.rv.adapter?.notifyDataSetChanged()
                    }

                    override fun onCancelled(error: DatabaseError) {
                        println(error.message)
                    }
                })

            GlobalScope.launch(Dispatchers.IO){

                val usuarioQuitar=FunDB.sacoUsuConIDDeLaBase(usuarioActualId)
                runOnUiThread {
                    lista_usuarios.remove(usuarioQuitar)
                    bind.rv.adapter?.notifyDataSetChanged()
                }

            }

            bind.rv.adapter=AdaptadorUsuarios(lista_usuarios,this)
            bind.rv.layoutManager= LinearLayoutManager(applicationContext)
        }else{
            val actividad= Intent(this,Login::class.java)
            this.startActivity(actividad)
        }



    }

    fun guardaespaldas():Boolean{
        var pasa=true
        val admin=SP.getBoolean(getString(R.string.admin),resources.getBoolean(R.bool.adminDef))?:false
        val idUsu=SP.getString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef))?:"vacio"
        if(idUsu=="vacio"){
            pasa=false
        }

        if(!admin){
            pasa=false
        }

        return pasa
    }


    override fun onBackPressed() {
        super.onBackPressed()

        val actividad= Intent(this,EditarUsuario::class.java)
        this.startActivity(actividad)
    }
}