package com.example.registrousuarios

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.registrousuarios.databinding.ActivityPaginaPrincipalBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class PaginaPrincipal : AppCompatActivity() {
    lateinit var bind:ActivityPaginaPrincipalBinding
    lateinit var SP:SharedPreferences
    lateinit var FunDB:BaseDatos

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind= ActivityPaginaPrincipalBinding.inflate(layoutInflater)
        setContentView(bind.root)
    }

    override fun onStart() {
        super.onStart()

        val app_id=resources.getString(R.string.app_id)
        val sp_name="${app_id}_SP_APP"
        SP=getSharedPreferences(sp_name,0)

        if (guardaespaldas()){

            FunDB= BaseDatos()
            var UsuarioPasado=Cuenta()
            GlobalScope.launch(Dispatchers.IO){
                UsuarioPasado=FunDB.sacoUsuConIDDeLaBase(SP.getString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef))?:"vacio")
            }

            bind.btnChats.setOnClickListener {
                //PARA PASAR UN OBJETO SOLO
                val intent= Intent(this,TiposChat::class.java)
                val bundle = Bundle()
                bundle.putParcelable("Usuario",UsuarioPasado)
                intent.putExtras(bundle)
                startActivity(intent)
            }

            bind.btnEditarInfo.setOnClickListener {
                val intent=Intent(this,EditarUsuario::class.java)
                startActivity(intent)
            }
        }else{
            val actividad= Intent(this,Login::class.java)
            this.startActivity(actividad)
        }

    }


    fun guardaespaldas():Boolean{
        var pasa=true

        val idUsu=SP.getString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef))
        if(idUsu=="vacio"){
            pasa=false
        }

        return pasa
    }
}