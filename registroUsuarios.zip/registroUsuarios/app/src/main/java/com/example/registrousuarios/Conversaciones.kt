package com.example.registrousuarios

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.CircularProgressDrawable
import com.bumptech.glide.request.RequestOptions
import com.example.registrousuarios.databinding.ActivityConversacionesBinding
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class Conversaciones : AppCompatActivity() {
    lateinit var bind:ActivityConversacionesBinding
    lateinit var adaptadorConv:AdaptadorConversaciones
    lateinit var FunDB:BaseDatos
    lateinit var db_ref: DatabaseReference
    lateinit var sto_ref: StorageReference
    lateinit var lista_usuarios:MutableList<Cuenta>
    lateinit var SP:SharedPreferences
    lateinit var lista_usuariosDisponibles:MutableList<Cuenta>
    lateinit var options:RequestOptions

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind= ActivityConversacionesBinding.inflate(layoutInflater)
        setContentView(bind.root)

        options = RequestOptions ()
            .placeholder(getLoader(this))
            .fallback(R.drawable.error)
            .error(R.drawable.error)
            .circleCrop()
    }

    override fun onStart() {
        super.onStart()

        FunDB= BaseDatos()

        lista_usuarios= mutableListOf()
        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()

        val app_id=resources.getString(R.string.app_id)
        val sp_name="${app_id}_SP_APP"
        SP=getSharedPreferences(sp_name,0)

        //PARA RECIBIRLO
        val bundle = intent.extras
        val objeto = bundle?.getParcelable<Cuenta>("Usuario")?:Cuenta()

        val usuarioActualId=SP.getString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef))?:"vacio"
        lista_usuariosDisponibles= mutableListOf()

        db_ref.child("Cuentas")
            .child("Usuarios")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    lista_usuarios.clear()
                    snapshot.children.forEach{ hijo: DataSnapshot?->

                        val pojo_poke=hijo?.getValue(Cuenta::class.java)

                        if(pojo_poke!!.disponible==true){

                            if(pojo_poke!!.id!=usuarioActualId){
                                lista_usuarios.add(pojo_poke!!)
                            }

                        }

                    }

                    bind.rvConv.adapter?.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })

        bind.rvConv.adapter=AdaptadorConversaciones(lista_usuarios,this,objeto)
        bind.rvConv.layoutManager= LinearLayoutManager(applicationContext)
    }

    fun getLoader(con:Context): CircularProgressDrawable {
        val circularProgressDrawable = CircularProgressDrawable(con)
        circularProgressDrawable.strokeWidth = 5f
        circularProgressDrawable.centerRadius = 30f
        circularProgressDrawable.start()
        return circularProgressDrawable
    }
}