package com.example.registrousuarios

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.CircularProgressDrawable
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.registrousuarios.databinding.ActivityChatBinding
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.database.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class Chat : AppCompatActivity() {
    lateinit var bind:ActivityChatBinding
    lateinit var SP:SharedPreferences
    lateinit var FunDB:BaseDatos
    lateinit var lista:MutableList<Mensaje>
    lateinit var options:RequestOptions

    val db_ref by lazy {
        FirebaseDatabase.getInstance().reference
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind= ActivityChatBinding.inflate(layoutInflater)
        setContentView(bind.root)

        options = RequestOptions ()
            .placeholder(getLoader(this))
            .fallback(R.drawable.error)
            .error(R.drawable.error)
            .circleCrop()
    }

    override fun onStart() {
        super.onStart()

        val app_id=resources.getString(R.string.app_id)
        val sp_name="${app_id}_SP_APP"
        SP=getSharedPreferences(sp_name,0)

        val idUsu=SP.getString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef))?:"vacio"

        lista= mutableListOf()
        //PARA RECIBIRLO
        val bundle = intent.extras
        val receptor = bundle?.getParcelable<Cuenta>("Receptor")?: Cuenta()
        val emisor = bundle?.getParcelable<Cuenta>("Emisor")?: Cuenta()

        FunDB= BaseDatos()

        Glide.with(this).load(receptor.imagenAvatar).apply(options).into(bind.chatImagen)
        bind.chatNombre.text=receptor.nombre

        bind.enviar.setOnClickListener {
            if(bind.mensajeEscribir.text!!.trim().isNotEmpty()){
                val mensaje=bind.mensajeEscribir.text.toString().trim()
                val hoy:Calendar= Calendar.getInstance()
                val pongoBienFecha=SimpleDateFormat("YYYY-MM-dd HH:mm:ss")
                val fecha=pongoBienFecha.format(hoy.time)

                val id_mensaje=db_ref.child("Chat").child("Mensajes").push().key!!
                val mensaje_nuevo=Mensaje(id_mensaje,emisor.id,receptor.id,mensaje,fecha)

                db_ref.child("Chat").child("Mensajes").child(id_mensaje).setValue(mensaje_nuevo)
                bind.mensajeEscribir.text!!.clear()
            }

        }

        db_ref.child("Chat").child("Mensajes").addChildEventListener(object: ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val objeto_mensaje=snapshot.getValue(Mensaje::class.java)
                if(objeto_mensaje!!.usu_emisor==emisor.id && objeto_mensaje!!.usu_receptor==receptor.id
                    || objeto_mensaje!!.usu_emisor==receptor.id && objeto_mensaje!!.usu_receptor==emisor.id){
                    lista.add(objeto_mensaje)
                }
                bind.rvChat.adapter!!.notifyDataSetChanged()
                bind.rvChat.scrollToPosition(lista.lastIndex)
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {

            }

            override fun onChildRemoved(snapshot: DataSnapshot) {

            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {

            }

            override fun onCancelled(error: DatabaseError) {

            }
        })

        val recycler = AdaptadorMensajes(lista,this,emisor,receptor)
        bind.rvChat.adapter = recycler
        bind.rvChat.layoutManager = LinearLayoutManager(applicationContext)
    }

    fun getLoader(con:Context): CircularProgressDrawable {
        val circularProgressDrawable = CircularProgressDrawable(con)
        circularProgressDrawable.strokeWidth = 5f
        circularProgressDrawable.centerRadius = 30f
        circularProgressDrawable.start()
        return circularProgressDrawable
    }

}