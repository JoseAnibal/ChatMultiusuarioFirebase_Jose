package com.example.registrousuarios

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import com.bumptech.glide.Glide
import com.example.registrousuarios.databinding.ActivityEditarUsuarioBinding
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class EditarUsuario : AppCompatActivity() {
    lateinit var bind:ActivityEditarUsuarioBinding
    var url_imagen:Uri?=null
    lateinit var db_ref: DatabaseReference
    lateinit var sto_ref: StorageReference
    lateinit var SP:SharedPreferences
    var primeravez=true

    lateinit var FunDB:BaseDatos

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editar_usuario)
        bind= ActivityEditarUsuarioBinding.inflate(layoutInflater)
        setContentView(bind.root)
    }

    override fun onStart() {
        super.onStart()
        FunDB=BaseDatos()


        val app_id=resources.getString(R.string.app_id)
        val sp_name="${app_id}_SP_APP"
        SP=getSharedPreferences(sp_name,0)

        if(guardaespaldas()){
            val idUsu=SP.getString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef))?:"vacio"
            val admin=SP.getBoolean(getString(R.string.admin),resources.getBoolean(R.bool.adminDef))

            bind.btnVerUsuarios.alpha=0.0f
            bind.btnVerUsuarios.isEnabled=false

            if(admin){
                bind.btnVerUsuarios.alpha=1.0f
                bind.btnVerUsuarios.isEnabled=true
            }

            db_ref= FirebaseDatabase.getInstance().reference
            sto_ref= FirebaseStorage.getInstance().reference

            var usuarioPasado:Cuenta?=null

            GlobalScope.launch(Dispatchers.IO){
                usuarioPasado=FunDB.sacoUsuConIDDeLaBase(idUsu)
                if(primeravez){
                    runOnUiThread {
                        bind.NombreUsuTitulo.text= usuarioPasado!!.nombre
                        bind.usuNombre.setText(usuarioPasado!!.nombre)
                        bind.usuMascota.isChecked= usuarioPasado!!.mascota?:false
                        bind.usuFechaRegistro.text= usuarioPasado!!.fechaRegistro
                        bind.usuDisponible.isChecked=usuarioPasado!!.disponible!!
                        bind.usuContrasena.setText(usuarioPasado!!.contrasena)
                        Glide.with(applicationContext).load(usuarioPasado!!.imagenAvatar).into(bind.usuImagen)
                        primeravez=false
                    }
                }


            }

            bind.btnGuardarCambios.setOnClickListener {

                if(!validacionFormulario(bind.usuNombre) || !validacionFormulario(bind.usuContrasena)){

                //}else if(bind.usuNombre.text.toString()==usuarioPasado!!.nombre && bind.usuContrasena.text.toString()==usuarioPasado!!.contrasena) {
                   // Toast.makeText(applicationContext, "No has modificado nada!", Toast.LENGTH_SHORT).show()
                }else{

                    bind.btnGuardarCambios.isEnabled=false

                    GlobalScope.launch(Dispatchers.IO){
                        if(!existeAntes(bind.usuNombre.text.toString(), usuarioPasado?.nombre.toString())){
                            runOnUiThread {
                                bind.usuNombre.error="Ese nombre ya existe!"
                            }
                            activoCorrutina(bind.btnGuardarCambios,true)
                        }else if(bind.usuContrasena.text.toString()=="") {
                            runOnUiThread {
                                bind.usuContrasena.error="Campo vacio"
                            }
                            activoCorrutina(bind.btnGuardarCambios,true)
                        }else{
                            //-------------------------------------------------
                            var url_imagen_firebase= usuarioPasado?.imagenAvatar
                            if(url_imagen!=null){
                                url_imagen_firebase=FunDB.insertoImagen(usuarioPasado?.imagenAvatar!!, url_imagen!!)
                            }
                            //-------------------------------------------------
                            val nom_usuEdit=bind.usuNombre.text.toString()
                            val contra_usuEdit=bind.usuContrasena.text.toString()
                            val mascota=bind.usuMascota.isChecked

                            if (usuarioPasado?.disponible==false && bind.usuDisponible.isChecked){
                                FunDB.insertoUsuarioId(idUsu,nom_usuEdit,contra_usuEdit,
                                    usuarioPasado?.admin!!,url_imagen_firebase!!, usuarioPasado!!.fechaRegistro!!,
                                    bind.usuDisponible.isChecked,mascota,Estados.DISPONIBLE, usuarioPasado!!.nombre.toString())
                            }

                            if (usuarioPasado?.nombre!=bind.usuNombre.text.toString()){
                                FunDB.insertoUsuarioId(idUsu,nom_usuEdit,contra_usuEdit,
                                    usuarioPasado?.admin!!,url_imagen_firebase!!, usuarioPasado!!.fechaRegistro!!,
                                    bind.usuDisponible.isChecked,mascota,Estados.NOMBRE_CAMBIADO, usuarioPasado!!.nombre.toString())
                            }

                            FunDB.insertoUsuarioId(idUsu,nom_usuEdit,contra_usuEdit,
                                usuarioPasado?.admin!!,url_imagen_firebase!!, usuarioPasado!!.fechaRegistro!!,
                                bind.usuDisponible.isChecked,mascota,Estados.NOTIFICADO, usuarioPasado!!.nombre.toString())
                            tostadaCorrutina("Cambios guardados")
                            usuarioPasado=FunDB.sacoUsuConIDDeLaBase(idUsu)
                            activoCorrutina(bind.btnGuardarCambios,true)
                        }


                    }
                }

            }

            bind.btnDarBaja.setOnClickListener {
                db_ref.child("Cuentas").child("Usuarios").child(usuarioPasado!!.id!!).child("notiEstados").setValue(Estados.DADOBAJA)

                sto_ref.child("Cuentas").child("imagenesUsuarios").child(idUsu).delete()
                db_ref.child("Cuentas").child("Usuarios").child(idUsu).removeValue()

                SP.edit().putString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef)).commit()
                val vueltaInicio=Intent(this,Login::class.java)
                startActivity(vueltaInicio)
                Toast.makeText(applicationContext, "Te has dado de baja", Toast.LENGTH_SHORT).show()
            }

            bind.btnDesconectarse.setOnClickListener {
                SP.edit().putString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef)).commit()
                SP.edit().putBoolean(getString(R.string.admin),false).commit()
                val vueltaInicio=Intent(this,Login::class.java)
                startActivity(vueltaInicio)
                Toast.makeText(applicationContext, "Te has desconectado", Toast.LENGTH_SHORT).show()
            }

            bind.usuImagen.setOnClickListener {
                obtener_url.launch("image/*")
            }

            bind.usuImagen.setOnLongClickListener {
                val ficheroFoto=FunDB.crearFicheroImagen(applicationContext)
                url_imagen= FileProvider.getUriForFile(applicationContext,"com.example.registrousuarios.fileprovider",ficheroFoto)
                getCamera.launch(url_imagen)
                true
            }

            bind.btnVerUsuarios.setOnClickListener {
                val verUsuarios=Intent(this,VerUsuarios::class.java)
                startActivity(verUsuarios)
            }

        }else{
            val actividad= Intent(this,Login::class.java)
            this.startActivity(actividad)
        }

    }

    private val getCamera=registerForActivityResult(ActivityResultContracts.TakePicture()){
        if(it){
            bind.usuImagen.setImageURI(url_imagen)

            Toast.makeText(applicationContext, "Foto hecha", Toast.LENGTH_SHORT).show()
        }else{
            Toast.makeText(applicationContext, "Nada", Toast.LENGTH_SHORT).show()
        }
    }

    fun existeAntes(nombreAcambiar:String,nombreUsu:String):Boolean{
        var pasa=true

            if(nombreAcambiar!=nombreUsu){
                val existe=FunDB.sacoUsuarioDeLaBase(nombreAcambiar)
                if(existe!=null){
                    pasa=false
                }
            }

        return pasa
    }

    fun guardaespaldas():Boolean{
        var pasa=true

        val idUsu=SP.getString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef))
        if(idUsu=="vacio"){
            pasa=false
        }

        return pasa
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val actividad= Intent(this,PaginaPrincipal::class.java)
        this.startActivity(actividad)
    }


    //----------ACTIVO/DESACTIVO BOTON CORRUTINA----------------
    private fun activoCorrutina(v: View, boolean: Boolean){
        runOnUiThread {
            v.isEnabled=boolean
        }
    }
    //------------------------------------------------

    fun validacionFormulario(e:EditText):Boolean{
        var valido=true
        if(e.text!!.isEmpty()){
            valido=false
            e.error="No puede estar vacio"
        }

        return valido
    }

    private val obtener_url= registerForActivityResult(ActivityResultContracts.GetContent()){
            uri: Uri?->
        when (uri){
            null-> Toast.makeText(applicationContext,"No has seleccionado ninguna imagen", Toast.LENGTH_SHORT).show()
            else->{
                url_imagen=uri
                bind.usuImagen.setImageURI(url_imagen)
                Toast.makeText(applicationContext,"Imagen seleccionada", Toast.LENGTH_SHORT).show()
            }
        }
    }

    //-------HACER UN TOAST EN UNA CORRUTINA--------------
    private fun tostadaCorrutina(texto:String){
        runOnUiThread{
            Toast.makeText(applicationContext,texto, Toast.LENGTH_SHORT).show()
        }
    }
    //------------------------------------------------------


}