package com.example.registrousuarios

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.CountDownLatch

class Registro : AppCompatActivity() {

    lateinit var reg_nombre:TextInputEditText
    lateinit var reg_contrasena:TextInputEditText
    lateinit var reg_contrasena2:TextInputEditText
    lateinit var reg_imagen:ImageView
    lateinit var reg_checkBox:CheckBox

    lateinit var db_ref:DatabaseReference
    lateinit var sto_ref:StorageReference

    lateinit var registrarse:Button
    var url_imagen:Uri?=null

    lateinit var FunDB:BaseDatos

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)
    }

    override fun onStart() {
        super.onStart()
        FunDB=BaseDatos()

        registrarse=findViewById(R.id.reg_btn_registrarse)

        reg_nombre=findViewById(R.id.reg_nombre)
        reg_contrasena=findViewById(R.id.reg_contrasena)
        reg_contrasena2=findViewById(R.id.reg_contrasenaN2)
        reg_imagen=findViewById(R.id.reg_imagen)
        reg_checkBox=findViewById(R.id.reg_checkbox)

        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()

        registrarse.setOnClickListener {

            if(reg_nombre.text.toString().trim().equals("") ||
                reg_contrasena.text.toString().trim().equals("") ||
                reg_contrasena2.text.toString().trim().equals("")){

                Toast.makeText(applicationContext, "No has rellenado todo", Toast.LENGTH_SHORT).show()

            }else if(url_imagen==null){
                Toast.makeText(applicationContext, "Ninguna imagen seleccionada", Toast.LENGTH_SHORT).show()
            }else if(reg_contrasena.text.toString().trim()!=reg_contrasena2.text.toString().trim()){
                Toast.makeText(applicationContext, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
            }else{
                registrarse.isEnabled=false
                GlobalScope.launch(Dispatchers.IO) {

                    if(FunDB.comprueboSiExiste(reg_nombre.text.toString().trim())){
                        tostadaCorrutina("Este nombre ya existe")
                        activoCorrutina(registrarse,true)
                    }else{
                        val genero_id= db_ref.child("Cuentas").child("Usuarios").push().key
                        val url_imagen_firebase=FunDB.insertoImagen(genero_id!!, url_imagen!!)

                        var ins_nombre=reg_nombre.text.toString()
                        var ins_contrasena=reg_contrasena.text.toString()
                        var ins_mascota=reg_checkBox.isChecked

                        val cal= Calendar.getInstance()
                        val hoy = "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.MONTH)+1}-${cal.get(
                            Calendar.DAY_OF_MONTH)}"

                        FunDB.insertoUsuarioId(genero_id!!,ins_nombre,ins_contrasena,false,url_imagen_firebase,
                        hoy,false,ins_mascota,Estados.CREADO,ins_nombre)

                        tostadaCorrutina("Usuario: ${ins_nombre} creado")

                        val vuelvoaMain=Intent(applicationContext,Login::class.java)
                        startActivity(vuelvoaMain)

                    }

                }

            }

        }

        reg_imagen.setOnClickListener {
            obtener_url.launch("image/*")
        }


        reg_imagen.setOnLongClickListener {
            val ficheroFoto=FunDB.crearFicheroImagen(applicationContext)
            url_imagen= FileProvider.getUriForFile(applicationContext,"com.example.registrousuarios.fileprovider",ficheroFoto)
            getCamera.launch(url_imagen)
            true
        }

    }

    private val getCamera=registerForActivityResult(ActivityResultContracts.TakePicture()){
        if(it){
            reg_imagen.setImageURI(url_imagen)

            Toast.makeText(applicationContext, "Foto hecha", Toast.LENGTH_SHORT).show()
        }else{
            Toast.makeText(applicationContext, "Nada", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val actividad= Intent(this,Login::class.java)
        this.startActivity(actividad)
    }

    //----------ACTIVO BOTON CORRUTINA----------------
    private suspend fun activoCorrutina(v: View, boolean: Boolean){
        runOnUiThread {
            v.isEnabled=boolean
        }
    }
    //------------------------------------------------

    //-------HACER UN TOAST EN UNA CORRUTINA------------
    private suspend fun tostadaCorrutina(texto:String){
        runOnUiThread{
            Toast.makeText(applicationContext,texto, Toast.LENGTH_SHORT).show()

        }
    }
    //---------------------------------------------------

    private val obtener_url= registerForActivityResult(ActivityResultContracts.GetContent()){
            uri:Uri?->
        when (uri){
            null-> Toast.makeText(applicationContext,"No has seleccionado ninguna imagen", Toast.LENGTH_SHORT).show()
            else->{
                url_imagen=uri
                reg_imagen.setImageURI(url_imagen)
                Toast.makeText(applicationContext,"Imagen seleccionada", Toast.LENGTH_SHORT).show()
            }
        }
    }


}