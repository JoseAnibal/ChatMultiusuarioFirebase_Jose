package com.example.registrousuarios

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.registrousuarios.databinding.FilaMensajeBinding

class AdaptadorMensajes(val lista:MutableList<Mensaje>, val contexto: Context, val emisor:Cuenta,val receptor:Cuenta): RecyclerView.Adapter<AdaptadorMensajes.ViewHolder>() {

    class ViewHolder(v: View): RecyclerView.ViewHolder(v){
    //EmpiezaEnMayuscula
        val bind = FilaMensajeBinding.bind(v)
    }
                                                                       //Recycler.ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdaptadorMensajes.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.fila_mensaje,parent,false)
        return ViewHolder(v)
    }
                                        //Recycler.ViewHolder
    override fun onBindViewHolder(holder: AdaptadorMensajes.ViewHolder, position: Int) {
        val l = lista[position]
        holder.bind.emisorImagen.visibility=View.VISIBLE
        holder.bind.receptorImagen.visibility=View.VISIBLE

        if(l.usu_emisor==emisor.id){
            with(holder.bind){
                receptorFecha.text=""
                receptorMensaje.text=""
                receptorImagen.visibility=View.INVISIBLE

                emisorFecha.text=l.fecha
                emisorMensaje.text=l.texto
            }

            Glide.with(contexto).load(emisor.imagenAvatar).apply((contexto as Chat).options).into(holder.bind.emisorImagen)
        }else{
            with(holder.bind){
                receptorFecha.text=l.fecha
                receptorMensaje.text=l.texto

                emisorFecha.text=""
                emisorMensaje.text=""
                emisorImagen.visibility=View.INVISIBLE
            }
            Glide.with(contexto).load(receptor.imagenAvatar).apply((contexto as Chat).options).into(holder.bind.receptorImagen)
        }


    }

    override fun getItemCount(): Int {
        return lista.size
    }


}