package com.example.registrousuarios

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class Cuenta(val id:String?=null, val nombre:String?=null,val contrasena:String?=null
,val admin:Boolean?=false,val imagenAvatar:String?=null,val fechaRegistro:String?=null,
val disponible:Boolean?=false,val mascota:Boolean?=false,var notiEstados:Int?=0,var nombreAnterior:String?=null):Parcelable
