package com.example.registrousuarios

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.registrousuarios.databinding.FilaUsuariosBinding
import java.io.Serializable

class AdaptadorUsuarios(val lista: MutableList<Cuenta>, val contexto: Context): RecyclerView.Adapter<AdaptadorUsuarios.ViewHolder>()  {

    class ViewHolder(v: View):RecyclerView.ViewHolder(v){
        val bind = FilaUsuariosBinding.bind(v)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdaptadorUsuarios.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.fila_usuarios,parent,false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: AdaptadorUsuarios.ViewHolder, position: Int) {
        val l = lista[position]

        with(holder.bind){
            nombre.setText("Nombre: ${l.nombre}")
            Glide.with(contexto).load(l.imagenAvatar).into(imagen)
            tvFecha.text="F.Reg: ${l.fechaRegistro}"
            editar.setOnClickListener {

                val actividad=Intent(contexto,AdminEditaUsu::class.java)
                actividad.putExtra("Cuenta",l as Serializable)
                contexto.startActivity(actividad)
            }
        }


    }

    override fun getItemCount(): Int {
        return lista.size
    }
}