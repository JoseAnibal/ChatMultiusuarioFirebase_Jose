package com.example.registrousuarios

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.example.registrousuarios.databinding.ActivityAdminEditaUsuBinding
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

class AdminEditaUsu : AppCompatActivity() {

    lateinit var bind:ActivityAdminEditaUsuBinding
    lateinit var cuenta:Cuenta
    lateinit var db_ref: DatabaseReference
    lateinit var sto_ref: StorageReference
    lateinit var SP:SharedPreferences

    lateinit var FunDB:BaseDatos

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_edita_usu)

        bind= ActivityAdminEditaUsuBinding.inflate(layoutInflater)
        setContentView(bind.root)
    }

    override fun onStart() {
        super.onStart()
        FunDB=BaseDatos()

        val app_id=resources.getString(R.string.app_id)
        val sp_name="${app_id}_SP_APP"
        SP=getSharedPreferences(sp_name,0)
        if(guardaespaldas()){
            db_ref= FirebaseDatabase.getInstance().getReference()
            sto_ref= FirebaseStorage.getInstance().getReference()

            cuenta=intent.getSerializableExtra("Cuenta") as Cuenta
            bind.nombreUsu.text="Nombre: ${cuenta.nombre}"
            Glide.with(applicationContext).load(cuenta.imagenAvatar).into(bind.imagenUsu)
            bind.adminUsu.text="Es admin: "
            bind.fechaUsu.text="F.Reg: ${cuenta.fechaRegistro}"
            bind.mascotaUsu.text="Mascota: "
            esAdmin()
            comprobadorImagenes()

            bind.eliminarUsu.setOnClickListener {
                sto_ref.child("Cuentas").child("imagenesUsuarios").child(cuenta.id!!).delete()
                db_ref.child("Cuentas").child("Usuarios").child(cuenta.id!!).removeValue()

                devolverAverUsuarios()
            }

            bind.promover.setOnClickListener {

                FunDB.insertoUsuarioId(cuenta.id!!,cuenta.nombre!!,cuenta.contrasena!!,true,cuenta.imagenAvatar!!,
                    cuenta.fechaRegistro!!,cuenta.disponible!!,cuenta.mascota!!,Estados.NONOTIFICAR,cuenta.nombreAnterior!!)
                Toast.makeText(applicationContext, "Usuario subido a admin!", Toast.LENGTH_SHORT).show()
                devolverAverUsuarios()

            }

            bind.guardarCambios.setOnClickListener {

                if(bind.contraseACambiar.length()==0){
                    bind.contraseACambiar.error="Campo vacio"
                }else{
                    FunDB.insertoUsuarioId(cuenta.id!!,cuenta.nombre!!,bind.contraseACambiar.text.toString(),cuenta.admin!!,cuenta.imagenAvatar!!,
                        cuenta.fechaRegistro!!,cuenta.disponible!!,cuenta.mascota!!,Estados.NONOTIFICAR,cuenta.nombreAnterior!!)

                    Toast.makeText(applicationContext, "Contraseña cambiada", Toast.LENGTH_SHORT).show()
                    devolverAverUsuarios()
                }

            }
        }else{
            val actividad= Intent(this,Login::class.java)
            this.startActivity(actividad)
        }



    }

    fun guardaespaldas():Boolean{
        var pasa=true
        val admin=SP.getBoolean(getString(R.string.admin),resources.getBoolean(R.bool.adminDef))?:false
        val idUsu=SP.getString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef))
        if(idUsu=="vacio"){
            pasa=false
        }
        if(!admin){
            pasa=false
        }

        return pasa
    }

    fun esAdmin(){
        if(cuenta.admin!!){
            bind.eliminarUsu.isEnabled=false
            bind.promover.isEnabled=false
            bind.contraseACambiar.isEnabled=false
            bind.contraseACambiar.alpha=0.0f
            bind.guardarCambios.isEnabled=false
            bind.invisible.alpha=0.0f
        }
    }

    fun devolverAverUsuarios(){
        val intent=Intent(this,VerUsuarios::class.java)
        startActivity(intent)
    }

    fun comprobadorImagenes(){
        if (cuenta.mascota!!){
            bind.imageMascota.setImageResource(R.drawable.sip)
        }else{
            bind.imageMascota.setImageResource(R.drawable.nope)
        }

        if(cuenta.admin!!){
            bind.imageAdmin.setImageResource(R.drawable.sip)
        }else{
            bind.imageAdmin.setImageResource(R.drawable.nope)
        }
    }
}