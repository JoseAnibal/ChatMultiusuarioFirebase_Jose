package com.example.registrousuarios

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.CircularProgressDrawable
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.registrousuarios.databinding.ActivityChatPublicoBinding
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import java.text.SimpleDateFormat
import java.util.*

class ChatPublico : AppCompatActivity() {
    lateinit var bind:ActivityChatPublicoBinding
    lateinit var opciones:RequestOptions
    lateinit var SP:SharedPreferences
    val db_ref by lazy {
        FirebaseDatabase.getInstance().reference
    }
    lateinit var listaPublica:MutableList<Mensaje>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind= ActivityChatPublicoBinding.inflate(layoutInflater)
        setContentView(bind.root)

        opciones = RequestOptions ()
            .placeholder(getLoader(this))
            .fallback(R.drawable.error)
            .error(R.drawable.error)
            .circleCrop()
    }

    override fun onStart() {
        super.onStart()

        val app_id=resources.getString(R.string.app_id)
        val sp_name="${app_id}_SP_APP"
        SP=getSharedPreferences(sp_name,0)

        val idUsu=SP.getString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef))?:"vacio"

        listaPublica= mutableListOf()
        //PARA RECIBIRLO
        val bundle = intent.extras
        val emisor = bundle?.getParcelable<Cuenta>("Usuario")?: Cuenta()

        bind.enviarPub.setOnClickListener {
            if(bind.mensajeEscribirPub.text!!.trim().isNotEmpty()){
                val mensaje=bind.mensajeEscribirPub.text.toString().trim()
                val hoy:Calendar= Calendar.getInstance()
                val pongoBienFecha=SimpleDateFormat("YYYY-MM-dd HH:mm:ss")
                val fecha=pongoBienFecha.format(hoy.time)

                val id_mensaje=db_ref.child("Chat").child("Mensajes").push().key!!
                val mensaje_nuevo=Mensaje(id_mensaje,emisor.id,"Grupo",mensaje,fecha)

                db_ref.child("Chat").child("Mensajes").child(id_mensaje).setValue(mensaje_nuevo)
                bind.mensajeEscribirPub.text!!.clear()
            }

        }

        db_ref.child("Chat").child("Mensajes").addChildEventListener(object: ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val objeto_mensaje=snapshot.getValue(Mensaje::class.java)
                //PONER CONDICION
                if (objeto_mensaje != null && objeto_mensaje.usu_receptor=="Grupo") {
                    listaPublica.add(objeto_mensaje)
                }

                bind.rvPublico.adapter!!.notifyDataSetChanged()
                bind.rvPublico.scrollToPosition(listaPublica.lastIndex)
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {

            }

            override fun onChildRemoved(snapshot: DataSnapshot) {

            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {

            }

            override fun onCancelled(error: DatabaseError) {

            }
        })

        val recycler = AdaptadorPublico(listaPublica,this,emisor)
        bind.rvPublico.adapter = recycler
        bind.rvPublico.layoutManager = LinearLayoutManager(applicationContext)

    }

    fun getLoader(con:Context): CircularProgressDrawable {
        val circularProgressDrawable = CircularProgressDrawable(con)
        circularProgressDrawable.strokeWidth = 5f
        circularProgressDrawable.centerRadius = 30f
        circularProgressDrawable.start()
        return circularProgressDrawable
    }
}