package com.example.registrousuarios

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.registrousuarios.databinding.FilaConversacionesBinding
import com.example.registrousuarios.databinding.FilaUsuariosBinding
import java.io.Serializable

class AdaptadorConversaciones(val lista: MutableList<Cuenta>, val contexto: Context,val emisor:Cuenta): RecyclerView.Adapter<AdaptadorConversaciones.ViewHolder>()  {

    class ViewHolder(v: View): RecyclerView.ViewHolder(v){
        val bind = FilaConversacionesBinding.bind(v)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdaptadorConversaciones.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.fila_conversaciones,parent,false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: AdaptadorConversaciones.ViewHolder, position: Int) {
        val l = lista[position]

        with(holder.bind){
            convNombre.text=l.nombre
            Glide.with(contexto).load(l.imagenAvatar).apply((contexto as Conversaciones).options).into(convImagen)
        }

        holder.bind.divClick.setOnClickListener {
            val intent= Intent(contexto,Chat::class.java)
            val bundle = Bundle()
            bundle.putParcelable("Receptor",lista[position])
            bundle.putParcelable("Emisor",emisor)
            intent.putExtras(bundle)
            contexto.startActivity(intent)
        }


    }

    override fun getItemCount(): Int {
        return lista.size
    }


}