package com.example.registrousuarios

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.registrousuarios.databinding.FilaMensajeBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class AdaptadorPublico(val lista:MutableList<Mensaje>, val contexto: Context, val emisor:Cuenta): RecyclerView.Adapter<AdaptadorPublico.ViewHolder>() {

    val TodasLasCuentas=mutableListOf<Cuenta>()

    val bd_ref = FirebaseDatabase.getInstance().getReference().child("Cuentas").child("Usuarios")
        .addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                TodasLasCuentas.clear()

                snapshot.children.forEach{hijo: DataSnapshot ->
                    val usuario=hijo?.getValue(Cuenta::class.java)
                    TodasLasCuentas.add(usuario!!)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                println(error.message)
            }
        })


    class ViewHolder(v: View): RecyclerView.ViewHolder(v){
        //EmpiezaEnMayuscula
        val bind = FilaMensajeBinding.bind(v)
    }
    //Recycler.ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdaptadorPublico.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.fila_mensaje,parent,false)
        return ViewHolder(v)
    }
    //Recycler.ViewHolder
    override fun onBindViewHolder(holder: AdaptadorPublico.ViewHolder, position: Int) {
        val l = lista[position]
        holder.bind.emisorImagen.visibility=View.VISIBLE
        holder.bind.receptorImagen.visibility=View.VISIBLE


        if(l.usu_emisor==emisor.id){
            with(holder.bind){
                receptorFecha.text=""
                receptorMensaje.text=""
                receptorImagen.visibility=View.INVISIBLE
                receptorNombre.text=""

                emisorFecha.text=l.fecha
                emisorMensaje.text=l.texto
                emisorNombre.text="Yo"
            }

            Glide.with(contexto).load(emisor.imagenAvatar).apply((contexto as ChatPublico).opciones).into(holder.bind.emisorImagen)
        }else{
            val enviador=TodasLasCuentas.find { it.id==l.usu_emisor }
            with(holder.bind){
                receptorFecha.text=l.fecha
                receptorMensaje.text=l.texto
                receptorNombre.text=enviador?.nombre

                emisorNombre.text=""
                emisorFecha.text=""
                emisorMensaje.text=""
                emisorImagen.visibility=View.INVISIBLE
            }
            Glide.with(contexto).load(enviador?.imagenAvatar).apply((contexto as ChatPublico).opciones).into(holder.bind.receptorImagen)
        }


    }

    override fun getItemCount(): Int {
        return lista.size
    }


}