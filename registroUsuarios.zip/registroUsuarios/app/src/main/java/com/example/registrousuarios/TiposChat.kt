package com.example.registrousuarios

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.registrousuarios.databinding.ActivityTiposChatBinding

class TiposChat : AppCompatActivity() {
    lateinit var bind:ActivityTiposChatBinding
    lateinit var SP:SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind= ActivityTiposChatBinding.inflate(layoutInflater)
        setContentView(bind.root)
    }

    override fun onStart() {
        super.onStart()
        val app_id=resources.getString(R.string.app_id)
        val sp_name="${app_id}_SP_APP"
        SP=getSharedPreferences(sp_name,0)

        if(guardaespaldas()){
            //PARA RECIBIRLO
            val bundle = intent.extras
            val objeto = bundle?.getParcelable<Cuenta>("Usuario")?: Cuenta()

            bind.chatPrivado.setOnClickListener {

                val intent= Intent(this,Conversaciones::class.java)
                val bundle = Bundle()
                bundle.putParcelable("Usuario",objeto)

                intent.putExtras(bundle)
                startActivity(intent)
            }

            bind.chatPublico.setOnClickListener {
                val intent=Intent(this,ChatPublico::class.java)
                val bundle = Bundle()
                bundle.putParcelable("Usuario",objeto)

                intent.putExtras(bundle)
                startActivity(intent)
            }
        }


    }

    fun guardaespaldas():Boolean{
        var pasa=true

        val idUsu=SP.getString(getString(R.string.id_usuario),getString(R.string.id_usuarioDef))
        if(idUsu=="vacio"){
            pasa=false
        }

        return pasa
    }
}